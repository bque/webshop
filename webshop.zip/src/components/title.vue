<template>
  <div class="title">
    <x-icon type="ios-arrow-back" class="icon" size="30"></x-icon>
    订单详情
  </div>
</template>

<script>
</script>

<style scoped>
.title {
  width: 100%;
  height: 3rem;
  background: white;
  font-size: 1.2rem;
  text-align: center;
  position: relative;
  line-height: 3rem;
}
.icon {
  position: absolute;
  left: 3%;
  top: 50%;
  transform: translate(0, -50%);
}
</style>